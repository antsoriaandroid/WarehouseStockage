# WarehouseStockage
This is a project to learn to use Angular and Node 
